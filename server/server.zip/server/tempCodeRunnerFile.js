let result = [];
// for (let rankId in ids) {
//   (async function start() {
//     let driver = await new Builder().forBrowser("chrome").build();
//     await driver.get(
//       `https://music.163.com/discover/toplist?id=${ids[rankId]}`
//     );
//     await driver.switchTo().frame(driver.findElement(By.id("g_iframe")));
//     let items = await driver.findElements(By.css("body tbody tr"));

//     console.log("items", items);
//     items.forEach(async (item, index) => {
//       // 获取岗位名称
//       // let title = await item.findElement(By.css('.p_top h3')).getText()
//       // musicurl
//       try {
//         let musicURL = await item.findElement(By.css(".tt a"));
//         let name = await item.findElement(By.css(".tt  .ttc .txt a b"));
//         let during = await item.findElement(By.css(".u-dur"));
//         let author = await item.findElement(By.css("td .text"));
//         let authorId = await item.findElement(By.css("td .text a"));
//         // https://music.163.com/song/media/outer/url?id=id.mp3
//         musicURL = await musicURL.getAttribute("href");
//         name = await name.getAttribute("title");
//         during = await during.getText();
//         author = await author.getAttribute("title");
//         authorId = await authorId.getAttribute("href");
//         let musicId = musicURL.split("=")[1];
//         let res = {
//           rankIndex: index,
//           musicURL: getMusicUrl(musicId),
//           musicName,
//           during,
//           author,
//           authorId: authorId.split("=")[1],
//           rankId: ids[rankId]
//         };
//         console.table("res", res);

//         result.push(res);
//       } catch {}
//     });
//   })();

// }

// function getMusicUrl(id) {
//   return `https://music.163.com/song/media/outer/url?id=${id}.mp3`;
// }