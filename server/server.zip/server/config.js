exports.dataBaseConfig = {
  host: '47.100.13.49',
  user: 'root',
  password: 'fb269948985',
  database:'bobzuishuai',
}
exports.jwtSecret = 'bobozuishuai'

